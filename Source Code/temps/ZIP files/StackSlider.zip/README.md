
StackSlider
=========

An experimental image slider that flips through images in 3D. Two stacks resemble image piles where images will be lifted off from and rotated to the center for viewing.

[article on Codrops](http://tympanus.net/codrops/?p=12566)

[demo](http://tympanus.net/Development/StackSlider)

Licensed under the MIT License