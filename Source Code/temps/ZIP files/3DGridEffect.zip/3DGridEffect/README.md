3D Grid Effect
=========

Recreation of the 3D effect seen in the [prototype app](https://www.youtube.com/watch?v=sjGF6Mw6X_Y) by Marcus Eckert.

[Article on Codrops](http://tympanus.net/codrops/?p=18742)

[Demo](http://tympanus.net/Development/3DGridEffect)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

Illustrations by [Adam Quest](https://www.behance.net/AdamQuest). 
Preloader by [Pixel Buddha](http://pixelbuddha.net/freebie/flat-preloaders).

[© Codrops 2013](http://www.codrops.com)